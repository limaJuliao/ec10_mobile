import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: "#fff",
      alignItems: "center",
      justifyContent: "center",
    },
  
    legenda: {
      fontSize: 30,
      color: "#f57e42",
      fontWeight: "bold",      
    },
    caixaTexto: {
      borderColor: "#000",
      borderRadius: 5,
      borderWidth: 2,
      width: "50%",
      fontSize: 25,
      padding: 10,
      marginBottom: 20,
    },
    botaoSoma: {
      marginTop: 10,
      width: 150,
      height: 40,
      backgroundColor: "#fc5203",
      borderRadius: 10,
      borderColor: "#d60b22",
      borderWidth: 1,
      alignItems: "center",
      justifyContent: 'center',
    },
    textoBotao: {
      color: "#FFF",
      fontWeight: "bold",
      fontSize: 20,
    },
    legendaCaixaTexto:{
      fontSize: 20,
      color: 'blue',
      marginBottom: 5,
    },

    resultado:{
      fontSize: 25,
      color: 'green',
      borderColor: 'green',
      borderWidth: 2,
      width: "90%",
      padding: 10,
      borderRadius: 10,
      marginTop: 20,
      textAlign: "center",
    },

    areaBotoes:{
      flexDirection: 'row',
      width: '100%',
      //backgroundColor: 'yellow',
      justifyContent: 'space-around',
    }
    
  });
  

  export default styles;