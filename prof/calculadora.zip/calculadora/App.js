import { StatusBar } from "expo-status-bar";
import { useState } from "react";
import { Text, TextInput, View, 
  TouchableOpacity, Image, Keyboard } from "react-native";

import styles from "./styles";
import iconeCalculadora from "./assets/calc.png";
import iconeAdicao from "./assets/adicao.png";
import iconeSubtracao from "./assets/subtracao.png";
import iconeMultiplicacao from "./assets/multiplicacao.png";
import iconeDivisao from "./assets/divisao.png";
import iconeLimpar from "./assets/clean.png";

export default function App() {
  const [valor1, setValor1] = useState(0);
  const [valor2, setValor2] = useState(0);
  const [resultado, setResultado] = useState(0);

  function soma() {
    let r =
      Number.parseFloat(valor1.replace(",", ".")) +
      Number.parseFloat(valor2.replace(",", "."));
    setResultado(r);
    Keyboard.dismiss();
  }

  function subtracao() {
    let r =
      Number.parseFloat(valor1.replace(",", ".")) -
      Number.parseFloat(valor2.replace(",", "."));
    setResultado(r);

    Keyboard.dismiss();
  }

  function multiplicacao() {
    let r =
      Number.parseFloat(valor1.replace(",", ".")) *
      Number.parseFloat(valor2.replace(",", "."));
    setResultado(r);
    Keyboard.dismiss();
  }

  function divisao() {
    let r =
      Number.parseFloat(valor1.replace(",", ".")) /
      Number.parseFloat(valor2.replace(",", "."));
    setResultado(r);
    Keyboard.dismiss();
  }

  function limpar() {
    setValor1(0);
    setValor2(0);
    Keyboard.dismiss();
  }

  return (
    <View style={styles.container}>
      <Image source={iconeCalculadora} />

      <Text style={styles.legenda}>Programa que soma valores </Text>

      <Text style={styles.legendaCaixaTexto}>Digite o primeiro valor </Text>
      <TextInput
        keyboardType="number-pad"
        onChangeText={(texto) => setValor1(texto)}
        style={styles.caixaTexto}
        value={valor1.toString()}
      />

      {/* <Text></Text>
      <Text></Text> */}

      <Text style={styles.legendaCaixaTexto}>Digite o segundo valor </Text>
      <TextInput
        keyboardType="numeric"
        onChangeText={(texto) => setValor2(texto)}
        style={styles.caixaTexto}
        value={valor2.toString()}
      />

      <View style={styles.areaBotoes}>
        <TouchableOpacity onPress={() => soma()}>
          <Image source={iconeAdicao} />
        </TouchableOpacity>

        <TouchableOpacity onPress={() => subtracao()}>
          <Image source={iconeSubtracao} />
        </TouchableOpacity>

        <TouchableOpacity onPress={() => multiplicacao()}>
          <Image source={iconeMultiplicacao} />
        </TouchableOpacity>

        <TouchableOpacity onPress={() => divisao()}>
          <Image source={iconeDivisao} />
        </TouchableOpacity>

        <TouchableOpacity onPress={() => limpar()}>
          <Image source={iconeLimpar} />
        </TouchableOpacity>
      </View>

      <Text style={styles.resultado}>Resultado: {resultado.toFixed(2)} </Text>

      <StatusBar style="auto" />
    </View>
  );
}
