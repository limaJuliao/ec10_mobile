import { StatusBar } from "expo-status-bar";
import { useState } from "react";
import { Text, TextInput, View, TouchableOpacity, Image } from "react-native";

import styles from "./styles";
import iconeCalculadora from './assets/calc.png';

export default function App() {
  const [valor1, setValor1] = useState(0);
  const [valor2, setValor2] = useState(0);
  const [resultado, setResultado] = useState(0);

  function soma() {
    let r =
      Number.parseFloat(valor1.replace(",", ".")) +
      Number.parseFloat(valor2.replace(",", "."));
    setResultado(r);
  }

  return (
    <View style={styles.container}>

      <Image source={iconeCalculadora}/>

      <Text style={styles.legenda}>Programa que soma valores </Text>

      <Text style={styles.legendaCaixaTexto}>Digite o primeiro valor </Text>
      <TextInput
        keyboardType="number-pad"
        onChangeText={(texto) => setValor1(texto)}
        style={styles.caixaTexto}
      />

      {/* <Text></Text>
      <Text></Text> */}

      <Text style={styles.legendaCaixaTexto}>Digite o segundo valor </Text>
      <TextInput
        keyboardType="numeric"
        onChangeText={(texto) => setValor2(texto)}
        style={styles.caixaTexto}
      />

      <TouchableOpacity onPress={() => soma()} style={styles.botaoSoma}>
        <Text style={styles.textoBotao}>Soma</Text>
      </TouchableOpacity>

      <Text style={styles.resultado}>Resultado: {resultado.toFixed(2)} </Text>

      <StatusBar style="auto" />
    </View>
  );
}
