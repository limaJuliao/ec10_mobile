import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import {
  StyleSheet, Text, TextInput, Alert,
  TouchableOpacity, View
} from 'react-native';

export default function App() {
  const [nome, setNome] = useState("");

  function exibeNome() {
    Alert.alert(nome);
  }

  return (
    <View style={styles.container}>

      <Text style={styles.label}>
        {nome}
      </Text>

      <Text style={styles.label}>
        Esta é a nossa 1a aplicação Mobile em React Native!
      </Text>
      <Text />

      <Text style={styles.label} >Digite o seu nome: </Text>
      <TextInput style={styles.caixaTexto}
        onChangeText={(text) => setNome(text)}
      />
      <Text />
      <TouchableOpacity style={styles.botao}
        onPress={exibeNome}  >
        <Text style={styles.label}>Pressione aqui!!!</Text>
      </TouchableOpacity>

      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  label: {
    fontSize: 25,
    fontWeight: 'bold',
    color: 'blue',
    textAlign: 'center',
  },
  caixaTexto: {
    fontSize: 20,
    fontWeight: 'bold',
    borderWidth: 1,
    borderRadius: 5,
    borderColor: '#000',
    width: '50%',
    paddingHorizontal: 5,
  },
  botao: {
    borderRadius: 10,
    width: '70%',
    height: 50,
    backgroundColor: '#BEE',
    justifyContent: 'center',

  },

  container: {
    flex: 1,
    backgroundColor: '#FFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
